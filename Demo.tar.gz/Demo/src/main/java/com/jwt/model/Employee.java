package com.jwt.model;

import javax.persistence.Entity;
import javax.persistence.*;

@Entity
@Table(name = "EMP_TBL")
public class Employee {
	private int id;
	private String name;
	private String email;
	private String address;
	private String telephone;
	
	public Employee() {
		super();
	}

	    
		


		public Employee(int id, String name, String email, String address, String telephone) {
			super();
			this.id = id;
			this.name = name;
			this.email = email;
			this.address = address;
			this.telephone = telephone;
		}


	
	 
		@Id
	    @GeneratedValue(strategy = GenerationType.AUTO)
		@Column(name="id")
	    public int getId() {
	        return id;
	    }
	 
	    public void setId(int id) {
	        this.id = id;
	    }
	 
	    @Column(name="name")
	    public String getName() {
	        return name;
	    }
	 
	    public void setName(String name) {
	        this.name = name;
	    }
	 
	    @Column(name="email")
	    public String getEmail() {
	        return email;
	    }
	 
	    public void setEmail(String email) {
	        this.email = email;
	    }
	 
	    @Column(name="address")
	    public String getAddress() {
	        return address;
	    }
	 
	    public void setAddress(String address) {
	        this.address = address;
	    }
	 
	    @Column(name="telephone")
	    public String getTelephone() {
	        return telephone;
	    }
	 
	    public void setTelephone(String telephone) {
	     this.telephone = telephone;
	    }


		@Override
		public String toString() {
			return "Employee [id=" + id + ", name=" + name + ", email=" + email + ", address=" + address
					+ ", telephone=" + telephone + "]";
		}
	 
	    
	}

